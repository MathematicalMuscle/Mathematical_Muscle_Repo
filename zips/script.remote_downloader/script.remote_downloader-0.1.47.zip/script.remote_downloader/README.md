## Installation via [`script.kodi_setter_upper`](https://github.com/MathematicalMuscle/script.kodi_setter_upper):

Modify the IP address and port and go to this URL in your browser:

[http://localhost:8080/jsonrpc?request={"jsonrpc":"2.0","id":1,"method":"Addons.ExecuteAddon","params":{"addonid":"script.kodi_setter_upper","params":{"ksu_class":"Addon","addonid":"script.remote_downloader","url":"https://github.com/MathematicalMuscle/script.remote_downloader/archive/master.zip"}}}](http://localhost:8080/jsonrpc?request={"jsonrpc":"2.0","id":1,"method":"Addons.ExecuteAddon","params":{"addonid":"script.kodi_setter_upper","params":{"ksu_class":"Addon","addonid":"script.remote_downloader","url":"https://github.com/MathematicalMuscle/script.remote_downloader/archive/master.zip"}}})

